"use client"

interface Project {
  title: string
  description: string
  tags: string[]
  category: string
  metrics?: string
  role?: string
  content: string
}

export default function ProjectDetail({ project }: { project: Project }) {
  return (
    <div className="pt-24 pb-20 min-h-screen">
      <div className="max-w-4xl mx-auto px-6">
        {/* 返回按钮 - 链接到首页#works */}
        <a
          href="/#works"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-amber transition-colors mb-8 cursor-pointer"
        >
          ← 返回项目列表
        </a>

        {/* 项目标题和标签 */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            {project.tags.map((tag) => (
              <span
                key={tag}
                className="text-xs px-2 py-0.5 rounded-full border border-amber/20 bg-amber/5 text-amber"
              >
                {tag}
              </span>
            ))}
          </div>
          <h1 className="text-3xl md:text-4xl font-semibold mb-2">{project.title}</h1>
          {project.role && (
            <p className="text-sm text-amber">{project.role}</p>
          )}
        </div>

        {/* 项目描述 */}
        <p className="text-lg text-muted-foreground leading-relaxed mb-8">
          {project.description}
        </p>

        {/* 项目内容 */}
        <div className="space-y-4 mb-8">
          {project.content.split('\n').map((line, i) => {
            const trimmed = line.trim()
            if (!trimmed) return null
            if (trimmed.startsWith('•') || trimmed.startsWith('-')) {
              return (
                <p key={i} className="text-muted-foreground ml-4">
                  {trimmed}
                </p>
              )
            }
            if (trimmed.includes('：') && trimmed.length < 30) {
              return (
                <p key={i} className="text-foreground font-semibold mt-4">
                  {trimmed}
                </p>
              )
            }
            return (
              <p key={i} className="text-muted-foreground">
                {trimmed}
              </p>
            )
          })}
        </div>

        {/* 项目成果 */}
        {project.metrics && (
          <div className="p-4 rounded-xl bg-amber/10 border border-amber/20">
            <h3 className="text-sm font-semibold text-amber mb-2">项目成果</h3>
            <p className="text-amber">{project.metrics}</p>
          </div>
        )}
      </div>
    </div>
  )
}