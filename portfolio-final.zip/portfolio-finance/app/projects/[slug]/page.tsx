import { notFound } from "next/navigation"
import ProjectDetail from "./project-detail"

const PROJECTS_DATA: Record<string, {
  title: string
  description: string
  tags: string[]
  category: string
  metrics?: string
  role?: string
  content: string
}> = {
  "ai-contract-platform": {
    title: "智能合同管理平台",
    description: "基于GPT/大模型能力，主导规划「智能发起—智能预审—履约管理」全链路AI产品方案并撰写完整PRD，推动合同全流程自动化与智能化建设。",
    tags: ["AI Agent", "RAG", "Multi-Agent", "GPT", "合同风控"],
    category: "AI",
    metrics: "退回率 78%→15%，审批周期 11天→3天，自动化处理率 70%，风险识别率 98%",
    role: "AI产品经理，项目负责人",
    content: `主导规划「智能发起—智能预审—履约管理」全链路AI产品方案并撰写完整PRD，推动合同全流程自动化与智能化建设。

设计多智能体（Multi-Agent）架构：
• 信息提取Agent（LLM语义理解+OCR）
• 企业风险审查Agent（天眼查API）
• 合同审核Agent（RAG知识库+规则引擎）
• 文本对比Agent

构建合同审查规则库，将公司合规制度与标准条款向量化入库，实现条款自动比对与合规风险标注。

协调技术，法务、财务多部门，将智能体嵌入泛微OA审批流程；主导UAT测试及交付上线，实现合同审批周期大幅压缩、一次性通过率显著提升。`,
  },
  "ai-wechat-miniapp": {
    title: "能吃嘛",
    description: "单人全栈操盘「能吃嘛」AI 饮食助手项目，全程使用 Vibe Coding 完成 0-1 MVP 落地。",
    tags: ["Vibe Coding", "微信小程序", "LLM", "uni-app"],
    category: "AI",
    content: `单人全栈操盘「能吃嘛」AI 饮食助手项目，全程使用 Vibe Coding 完成 0-1 MVP 落地。

核心设计：
• RAG 检索增强知识库，沉淀食材成分、肾病分期、临床指南等专业数据
• 搭建自然语言意图识别模块，拆解问答全链路逻辑
• 让 AI 精准理解用户饮食咨询诉求并输出合规专业建议

兼顾领域：
• 知识库迭代
• 接口规划
• 适老化体验
• 医疗合规与运营体系设计

实现 AI 能力，产品功能，业务运营一体化落地。`,
  },
  "recharge-consumption": {
    title: "营销费用业务一体化",
    description: "平台店铺/营销费用充值消耗全流程管理系统",
    tags: ["费控", "对账", "OA集成", "NC对接"],
    category: "财务",
    metrics: "效率提升 70%，数据合规率 100%",
    content: `项目名称：平台店铺/营销费用充值消耗全流程管理系统

项目概述：
本项目针对电商平台店铺的充值、消耗，入账、报销，品牌应收等环节存在的手工操作多，数据孤岛、流程割裂等痛点，通过打通OA、FFC、NC三大系统，构建了一套覆盖账户统一管控 → 充值申请与付款 → 消耗清单自动获取与汇总 → 费用统一入账 → 发票报销与消耗单关联 → 品牌应收追溯的全链路自动化闭环管理平台。

核心系统集成方案设计与落地：
• 主导跨部门协作，完成三系统接口对接方案设计（余额实时调用、自动消耗清单同步，单据状态关联回写），确保数据一致性
• 联动业务与开发团队推进验收上线，并制定期初数据迁移方案，保障系统平滑切换

关键风控机制设计：
• 实时余额校验
• 超额付款升级审批
• 申请单到期自动关闭及关联付款单回收
• 报销三单金额平衡校验等核心风控逻辑

最终价值：消除数据孤岛，实现业务单据系统化流转与财务入账自动化，提升整体作业效率。`,
  },
  "multi-channel-settlement": {
    title: "代销仓结算系统",
    description: "多渠道代销仓结算",
    tags: ["结算", "代销", "库存管理"],
    category: "财务",
    metrics: "2023 年项目金奖，亿级负库存清零",
    content: `多渠道代销仓结算（天猫、京东、唯品会、屈臣氏），解决亿级负库存至审计可接受水平，2023年公司金奖。`,
  },
  "travel-expense-control": {
    title: "差旅费控系统",
    description: "差旅费用全链路管控",
    tags: ["费控", "携程API", "滴滴API"],
    category: "财务",
    metrics: "服务 1500+ 员工",
    content: `服务集团1500+员工，对接携程、滴滴，实现差旅申请→预订→报销全流程线上化，降低差旅成本。`,
  },
  "erp-u9-implementation": {
    title: "ERP-U9财务系统上线",
    description: "用友ERP-U9从零上线",
    tags: ["ERP实施", "用友NC", "财务模块"],
    category: "财务",
    metrics: "月结效率 5天→1天",
    content: `主导用友ERP-U9从零上线，替代不适用的金蝶系统，月结时间从5天优化至1天。`,
  },
  "oa-finance-workflow": {
    title: "泛微OA财务流程平台",
    description: "财务审批流程搭建",
    tags: ["泛微OA", "流程配置", "内控授权"],
    category: "其他",
    metrics: "覆盖 1500+ 用户",
    content: `面向1500+用户，统筹财务审批流程搭建、内控授权配置与全链路流程落地。`,
  },
  "yinhang-zhilian": {
    title: "银企直联",
    description: "银企直联对接",
    tags: ["银企直联", "支付"],
    category: "其他",
    content: `银企直联三方对接与测试，实现支付自动化。`,
  },
}

export default async function ProjectPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const project = PROJECTS_DATA[slug]

  if (!project) {
    notFound()
  }

  return <ProjectDetail project={project} />
}