import type React from "react"
import type { Metadata, Viewport } from "next"
import { Inter_Tight } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { MagneticCursor } from "@/components/ui/magnetic-cursor"
import "./globals.css"

const interTight = Inter_Tight({
  subsets: ["latin"],
  variable: "--font-inter-tight",
})

export const metadata: Metadata = {
  title: "Jayne Chen | AI × 财务 产品经理",
  description: "财务管理专业出身，11年工作经验，主导AI大模型产品从0到1落地。深耕财务/合同风控领域，具备Multi-Agent + RAG + Vibe Coding能力。",
  keywords: ["财务产品经理", "AI产品经理", "产品经理", "财务管理", "AI大模型"],
  authors: [{ name: "Jayne Chen" }],
  openGraph: {
    title: "Jayne Chen | AI × 财务 产品经理",
    description: "财务管理专业出身，11年工作经验，主导AI大模型产品从0到1落地。",
    type: "website",
  },
}

export const viewport: Viewport = {
  themeColor: "#ffffff",
  width: "device-width",
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${interTight.className} font-sans antialiased`}>
        <MagneticCursor />
        {children}
        <Analytics />
      </body>
    </html>
  )
}
